export CLASSPATH=osgi/org.eclipse.equinox.launcher_1.3.0.v20140415-2008.jar
java org.eclipse.equinox.launcher.Main -configuration file:configuration/ -os linux -ws gtk -arch x86_64 -nl en_US